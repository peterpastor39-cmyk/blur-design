import type { Metadata } from "next";
import HeroStudy from "@/variants/blur-v2-wip/home";

export const metadata: Metadata = { title: "Blur — Version 2", description: "Blur Design hero with an Allia-inspired image wheel." };

export default function HeroStudyPage() { return <HeroStudy />; }
