export { default } from "./HeroStudy";
